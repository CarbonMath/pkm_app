package com.pkm_app.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    Button button1;
    private ImageSlider imageSlider;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        getSupportActionBar().hide();

        imageSlider = findViewById(R.id.image_slider);
        ArrayList<SlideModel> slideModels=new ArrayList<>();
        slideModels.add(new SlideModel(R.drawable.imageslider1, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.imageslider2, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.imageslider3, ScaleTypes.FIT));
        imageSlider.setImageList(slideModels, ScaleTypes.FIT);


    }

    public void openMenu(View view) {

        startActivity(new Intent(this,jelajahiActivity.class));
    }

    public void openactivity_panduan(View view) {
        startActivity(new Intent(this,panduan.class));
    }
}